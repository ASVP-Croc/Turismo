package com.speriamochemelacavo.turismo2024;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Turismo2024ApplicationTests {

	@Test
	void contextLoads() {
	}

}
